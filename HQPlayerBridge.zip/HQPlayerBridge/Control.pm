package Plugins::HQPlayerBridge::Control;

# Async XML control client for a single HQPlayer instance (TCP port 4321).
#
# Protocol facts (verified against a live hqplayerd and against the working
# reference client zeropointnine/hqpwv):
#
#   * Each request is the literal string
#         <?xml version="1.0" encoding="UTF-8"?>
#     immediately followed by the command element.  No newline, no length
#     prefix, nothing else.
#   * Exactly ONE command may be in flight at a time.  Pipelining desyncs the
#     stream, so every request is queued and issued strictly in order.
#   * Unknown commands are answered with result="Error" and the text
#     "Unknown command", and the link SURVIVES - verified live 2026-08-26.
#     (An earlier note claiming HQPlayer closes the socket on unrecognised XML
#     came from a third-party client and is wrong.)  The %KNOWN whitelist below
#     is kept anyway: it costs nothing, keeps typos out of the wire, and means
#     a caller gets a clean failed callback instead of a puzzling Error reply.
#   * Every command answers with its OWN root tag, so replies are matched by
#     tag name.  Only an explicit result="Error" counts as failure.
#   * <Status/> IS A SUBSCRIBE.  Verified live: playing pushes nothing and
#     seeking pushes nothing, but once a single <Status/> has been sent
#     HQPlayer streams Status messages at roughly 1/s, unsolicited, for as long
#     as the link is up.  Several can therefore arrive in one read, and one can
#     land between a request and its reply.  So the reader below extracts one
#     complete message at a time and matches replies BY ROOT ELEMENT NAME
#     rather than assuming the next message is the answer.
#
# All socket IO here is non-blocking and driven from Slim::Networking::Select,
# so nothing in this module may ever block the LMS event loop.

use strict;
use warnings;

use IO::Socket::INET;
use Socket qw(SOL_SOCKET SO_ERROR inet_aton pack_sockaddr_in);
use Errno  qw(EINPROGRESS EWOULDBLOCK EAGAIN EINTR);

# The socket carries OCTETS.  See _pump and _dispatch - a wide character
# reaching syswrite is fatal, and it takes the whole command queue with it.
use Encode ();

use Time::HiRes ();

use Slim::Networking::Select;
use Slim::Utils::Log;
use Slim::Utils::Timers;

my $log = logger('plugin.hqplayerbridge');

use constant HQP_PORT        => 4321;
use constant XML_DECL        => '<?xml version="1.0" encoding="UTF-8"?>';
use constant CONNECT_TIMEOUT => 5;
# PlaylistAdd makes HQPlayer fetch and probe the media before it answers, so
# the reply window has to cover a slow origin, not just a round trip.
use constant REPLY_TIMEOUT   => 30;
use constant BACKOFF_MIN     => 2;
# The link keeps ITSELF alive, and this is how far apart its attempts get.
# 10s, not the 60s it was: until 2026-09-27 discovery poked a down link every
# 10s round (reconnectNow), and that poke was the real return time after a
# long outage. The link now owns it, on its own ladder, and discovery is out
# of the loop - docs/discovery-simplification-plan.md.
use constant BACKOFF_MAX     => 10;
use constant SLOW_COMMAND    => 1;

# The complete verified command vocabulary, extracted from the hqplayerd
# binary.  Anything not in here must not go on the wire - see the note about
# socket closes above.
# SetVolume/SetVolumeDB/GetVolume are deliberately ABSENT: they are UPnP
# RenderingControl action names that also appear in the binary, and the XML
# control API answers "Unknown command" to all three.
# NOTE on volume: the command is plain <Volume value="-53"/>, in dB, and the
# current level comes back on every <Status/> as volume="-53".  Probed against
# the live daemon 2026-08-27: SetVolume, SetVolumeDB and GetVolume are all
# "Unknown command" - an earlier guess from the binary's strings was wrong.
#
# THE COMMAND SET IS NO LONGER GUESSWORK.  Signalyst ship the source of their
# own `hqp-control` client (hqp-control-601-src/ in the repo root), and
# ControlInterface.cpp writes every command this API has.  The full list, from
# its writeStartElement/writeEmptyElement calls:
#
#   Backward Forward Next Previous Play Pause Stop Seek SelectTrack
#   Status State GetInfo GetLicense Reset LoadRemovable
#   PlayNextURI
#   PlaylistAdd PlaylistClear PlaylistDelete PlaylistGet PlaylistGetAll
#   PlaylistGetList PlaylistGetSingle PlaylistLoad PlaylistMoveDown
#   PlaylistMoveUp PlaylistRemove PlaylistSave PlaylistUpload
#   Volume VolumeRange VolumeUp VolumeDown VolumeMute SetAdaptiveVolume
#   SetConvolution SetDisplay GetDisplay SetFilter GetFilters SetInvert
#   SetJunkFilter GetJunkFilters SetMode GetModes SetRandom SetRate GetRates
#   SetRepeat SetShaping GetShapers SetTransport SetTransportPath
#   SetTransportRate GetTransport GetInputs
#   ConfigurationGet ConfigurationList ConfigurationLoad
#   LibraryFavoriteGet LibraryFavoriteSet LibraryFavoriteSetCurrent
#   LibraryGet LibraryGetHash LibraryLoad LibraryPicture
#   MatrixGetProfile MatrixListProfiles MatrixSetProfile
#   SessionAuthentication
#
# TRAP WHEN EXTRACTING THAT LIST: one command - and it is the one that matters
# most here - is written as writeEmptyElement("VolumeRange") with a PLAIN
# string literal, while every other command uses QStringLiteral(...).  A grep
# for QStringLiteral misses it, and missing it is what kept UPnP.pm alive.
# Match both forms.
#
# <VolumeRange/> IS A CONTROL COMMAND, AND IT REPLACES UPnP ENTIRELY.  Verified
# live 2026-08-28 against engine 6.0.4:
#
#   <VolumeRange adaptive="1" enabled="1" max="0" min="-100"/>
#
# Same range UPnP GetVolumeDBRange reports, in plain dB rather than 1/256, on
# the socket that is already open and answers in ~9ms instead of 300-550ms.
# `enabled` is not a fixed-volume flag and is deliberately ignored; that was
# measured with HQPlayer's configured startup level applied and the range still
# fully active. GetVolumeDBRange/GetVolumeDB really are absent - those are the
# UPnP action names, and the earlier note inferring "so there is no way to ask"
# from their absence stopped one command short.
#
# PlayNextURI IS IN THE LIST BUT MUST NOT BE SENT.  It answers result="OK" and
# then TAKES HQPLAYERD DOWN - see CLAUDE.md.  It is whitelisted only so that
# tools/probe_gapless.py can re-test it deliberately on a future engine.
#
# Only what the plugin actually sends is whitelisted here.
my %KNOWN = map { $_ => 1 } qw(
    Play Pause Stop Seek SelectTrack Status State GetInfo Volume SetRepeat
    PlaylistAdd PlaylistClear PlaylistGet PlayNextURI VolumeRange
    GetTransport SetTransport GetInputs GetRates GetModes GetFilters
);

# Errors that are not failures.  VERIFIED live 2026-08-27: with an EMPTY
# playlist, every <Volume> answers result="Error" with an album-gain message -
# and applies the level anyway (GetVolumeDB confirms it to 1/256 dB).  It is
# HQPlayer recomputing replaygain for a playlist that has no tracks, not a
# rejection, so logging it as a failure would cry wolf on every volume change
# made while the player is idle.
my %BENIGN = ( Volume => qr/GetAlbumGain/i );

sub new {
    my ($class, %args) = @_;

    my $self = bless {
        ip        => $args{ip},
        name      => $args{name} || $args{ip},
        onState   => $args{onState},      # called as $cb->($self, 1) at the
                                          # accept, and $cb->($self, 0, $wasProven)
                                          # when a link that was up drops
        onStatus  => $args{onStatus},     # called as $cb->($attrs, $raw) for
                                          # EVERY Status message, pushed or not
        onProven  => $args{onProven},     # called as $cb->($self) ONCE per link,
                                          # at HQPlayer's first reply - see proven
        # One command and done: never reconnects, and logs only at debug -
        # the caller reports. See identify.
        oneShot   => $args{oneShot} ? 1 : 0,
        queue     => [],
        wbuf      => '',
        rbuf      => '',
        inflight  => undef,
        sock      => undef,
        connected => 0,
        connecting=> 0,
        # A completed TCP handshake is NOT proof of a working link - see
        # _connectResolved.  This flips only when HQPlayer actually says
        # something, and it is what gates the backoff reset.
        proven    => 0,
        backoff   => BACKOFF_MIN,
        closing   => 0,
        # This outage has been reported - see _outage.
        quiet     => 0,
    }, $class;

    return $self;
}

sub ip        { $_[0]->{ip} }
sub name      { $_[0]->{name} }
sub connected { $_[0]->{connected} }

# The link has carried a reply - the first real evidence HQPlayer is serving.
# `connected` is only the TCP accept, which hqplayerd also gives when it is
# about to drop the socket (no endpoint, expired trial). LMS's view of the
# player - Player::connected - is this, not that.
sub proven    { $_[0]->{proven} }

# Will send() accept a command?  The SAME sock-or-connecting test send() makes,
# so the two cannot drift: a link that is still connecting queues, a link that
# is down fails on the next event-loop turn.  Callers that must not begin work
# send() would reject - Player::_queueTrack - ask this, not `connected`, which
# is false for the whole of a reconnect that will nevertheless carry the load.
sub up        { ( $_[0]->{sock} || $_[0]->{connecting} ) ? 1 : 0 }

# ---------------------------------------------------------------------------
# Public: queue a command.
#   $cmd is the bare element, e.g. '<Play/>' or '<Seek position="30"/>'
#   $cb  is called as $cb->($attrs_hashref, $raw_xml) on success,
#        or $cb->(undef, undef) if the command failed, the link dropped, or
#        the link was already down when it was sent.
#   $opts->{scope} groups commands which may be cancelled before they reach
#        the wire; the player uses 'track' for generation-bound load work.
#
# Returns nothing: every caller is driven by its $cb, which is failed on a
# refusal as well as on a drop.
# ---------------------------------------------------------------------------
sub send {
    my ($self, $cmd, $cb, $opts) = @_;

    $opts = {} unless ref $opts eq 'HASH';

    my ($verb) = $cmd =~ /^<([A-Za-z]\w*)/;
    if ( !$verb || !$KNOWN{$verb} ) {
        $log->error("refusing to send unverified command (would drop the link): $cmd");
        $cb->(undef, undef) if $cb;
        return;
    }

    # THE LINK IS DOWN: fail the command, and do NOT connect. A reconnect is
    # already on its way - _create opens the first link, and every drop or
    # failed connect schedules the next one with backoff - or the link is
    # being closed for good. This used to connect at once, which skipped the
    # backoff for every command LMS sends a disconnected player (a sync
    # group's _JumpToTime, unsync's _stopClient, playerInactive's Stop), did
    # it from inside _dropLink when a link-down listener sent something, and
    # left the command queued for whatever link came next. Two call sites had
    # grown workarounds for it (Plugin::_onLinkState, Player::forgetClient).
    #
    # Failed on the NEXT event-loop turn, not inside this call: a caller's
    # failure path (a refused load -> playerStreamingFailed -> LMS loading the
    # next track) must not re-enter code that is still in the middle of
    # sending.
    if ( !$self->{sock} && !$self->{connecting} ) {
        main::DEBUGLOG && $log->is_debug && $log->debug("$self->{name}: link down, not sending <$verb>");
        Slim::Utils::Timers::setTimer( $self, Time::HiRes::time(), \&_failLater, $cb ) if $cb;
        return;
    }

    push @{ $self->{queue} }, {
        cmd      => $cmd,
        cb       => $cb,
        verb     => $verb,
        scope    => $opts->{scope},
        queuedAt => Time::HiRes::time(),
    };

    $self->_pump;

    return;
}

sub _failLater {
    my ( $self, $cb ) = @_;
    $cb->( undef, undef );
}

# Drop work which is still WAITING behind the command on the wire. An
# in-flight request cannot be cancelled safely: the only way to do that would
# be to tear down the ordered control connection, and its late side effects
# would then race the replacement load. Queued commands have not reached
# HQPlayer, though, so a new track generation can remove them cleanly.
sub cancelQueued {
    my ( $self, $scope ) = @_;

    return 0 unless defined $scope && $scope ne '';

    my ( @keep, @drop );

    for my $req ( @{ $self->{queue} || [] } ) {
        if ( defined $req->{scope} && $req->{scope} eq $scope ) {
            push @drop, $req;
        }
        else {
            push @keep, $req;
        }
    }

    $self->{queue} = \@keep;

    # Preserve send()'s callback contract. Player callbacks are generation-
    # stamped, so after _newGeneration they recognise this as superseded and
    # do not turn a deliberate cancellation into a failed load.
    $_->{cb}->( undef, undef ) for grep { $_->{cb} } @drop;

    main::DEBUGLOG && $log->is_debug && @drop && $log->debug(
        "$self->{name}: cancelled " . scalar(@drop) . " queued $scope command(s)" );

    return scalar @drop;
}

# ---------------------------------------------------------------------------
# Connection management
# ---------------------------------------------------------------------------
sub connect {
    my $self = shift;

    return if $self->{sock} || $self->{connecting} || $self->{closing};

    my $sock = IO::Socket::INET->new(
        Proto    => 'tcp',
        Blocking => 0,
    );

    if ( !$sock ) {
        $self->_outage("cannot create socket: $!");
        return $self->_scheduleReconnect;
    }

    my $addr = pack_sockaddr_in( HQP_PORT, inet_aton( $self->{ip} ) );

    $self->{sock}       = $sock;
    $self->{connecting} = 1;

    # Non-blocking connect: EINPROGRESS is the expected outcome.
    if ( !CORE::connect( $sock, $addr ) ) {
        my $err = $!;
        if ( $err != EINPROGRESS && $err != EWOULDBLOCK ) {
            $self->_outage("connect failed immediately: $err");
            return $self->_dropLink("connect: $err");
        }
    }

    # Writability signals that the connect has resolved (either way).
    Slim::Networking::Select::addWrite( $sock, sub { $self->_connectResolved } );
    Slim::Networking::Select::addError( $sock, sub { $self->_dropLink('select error during connect') } );

    Slim::Utils::Timers::setTimer( $self, Time::HiRes::time() + CONNECT_TIMEOUT, \&_connectTimeout );

    main::DEBUGLOG && $log->is_debug && $log->debug("$self->{name}: connecting to $self->{ip}:" . HQP_PORT);

    return;
}

sub _connectResolved {
    my $self = shift;
    my $sock = $self->{sock} or return;

    Slim::Utils::Timers::killTimers( $self, \&_connectTimeout );
    Slim::Networking::Select::removeWrite($sock);

    # SO_ERROR carries the real outcome of a non-blocking connect.
    my $packed = getsockopt( $sock, SOL_SOCKET, SO_ERROR );
    my $err    = $packed ? unpack( 'I', $packed ) : 0;

    if ($err) {
        $! = $err;
        $self->_outage("connect refused: $!");
        return $self->_dropLink("connect: $!");
    }

    $self->{connecting} = 0;
    $self->{connected}  = 1;

    # DELIBERATELY NOT resetting the backoff here.  hqplayerd ACCEPTS the
    # socket and only then decides it cannot serve - it logs
    # "Control connection from <ip>" followed immediately by
    # "clControlThread::HandleConnection(): std::exception" and closes.  That
    # is its normal behaviour whenever its output endpoint is missing, e.g.
    # the NAA is switched off.
    #
    # Resetting on the handshake made every one of those look like a success,
    # so the ladder never climbed: measured 2,324 accept-then-drop cycles in
    # 9.5 hours against an HQPlayer whose endpoint was powered down, instead
    # of settling at one attempt per BACKOFF_MAX.  The reset moved to
    # _dispatch, which only runs when HQPlayer has actually said something.
    $self->{proven} = 0;

    if ( $self->{oneShot} ) {
        main::DEBUGLOG && $log->is_debug && $log->debug("$self->{name}: connected to identify it");
    }
    else {
        main::INFOLOG && $log->is_info && $log->info("$self->{name}: control link up ($self->{ip})");
    }

    Slim::Networking::Select::addRead( $sock, sub { $self->_readable } );

    $self->{onState}->( $self, 1 ) if $self->{onState};

    $self->_pump;

    return;
}

sub _connectTimeout {
    my $self = shift;
    $self->_outage( 'connect timed out after ' . CONNECT_TIMEOUT . 's' );
    $self->_dropLink('connect timeout');
}

sub _replyTimeout {
    my $self = shift;
    my $verb = $self->{inflight} ? $self->{inflight}->{verb} : '(none)';
    my $msg  = "no reply to <$verb> after " . REPLY_TIMEOUT . 's';
    # A link that had been answering going silent is news - and _dropLink
    # already WARNs for a proven link, so it carries the reason as its own
    # line ("control link down - no reply to <X> after 30s") rather than a
    # second WARN for the same event.  An accept that never answered is one
    # more failed attempt of an outage.
    return $self->_dropLink($msg) if $self->{proven};
    $self->_outage($msg);
    $self->_dropLink('reply timeout');
}

# ---------------------------------------------------------------------------
# Writing
# ---------------------------------------------------------------------------
sub _pump {
    my $self = shift;

    return unless $self->{connected} && $self->{sock};
    return if $self->{inflight};

    my $next = shift @{ $self->{queue} } or return;

    $self->{inflight} = $next;
    $next->{sentAt} = Time::HiRes::time();

    # ENCODE TO OCTETS HERE, AND NOWHERE ELSE.  `wbuf` is a BYTE buffer from
    # this line on.
    #
    # LMS hands out track titles as Perl CHARACTER strings, so the moment an
    # album has a track called "Lush 3-1" with a U+2012 figure dash in it, the
    # <metadata song="..."/> on a PlaylistAdd carries a wide character - and
    # `syswrite` on a raw socket DIES with "Wide character in syswrite".
    #
    # THAT DIE IS CATASTROPHIC, NOT COSMETIC.  It throws out of the status
    # handler that was pumping the queue, the command stays `inflight`
    # forever, and because exactly one command may be in flight at a time
    # EVERY SUBSEQUENT COMMAND IS QUEUED BEHIND IT AND NEVER SENT.  The player
    # goes deaf: skip, stop and pause all do nothing, LMS's position freezes
    # while HQPlayer plays on, and 30s later the reply timeout tears the link
    # down.  Observed live 2026-08-28 on Orbital 2.
    #
    # It is invisible for ASCII-only libraries, which is why it survived every
    # test up to here.  Same family as the LMS characters-vs-octets trap:
    # anything that reaches a socket, a DB or a digest needs BYTES.
    #
    # The second, quieter half: `substr($wbuf, 0, $wrote, '')` in _flush cuts
    # by CHARACTER while syswrite counts BYTES, so a partial write of a
    # non-ASCII command would resume mid-character and corrupt the stream.
    # Encoding once, here, makes both operations agree.
    $self->{wbuf} .= Encode::encode( 'UTF-8', XML_DECL . $next->{cmd} );

    main::DEBUGLOG && $log->is_debug && $log->debug("$self->{name}: -> $next->{cmd}");

    Slim::Utils::Timers::setTimer( $self, Time::HiRes::time() + REPLY_TIMEOUT, \&_replyTimeout );

    $self->_flush;

    return;
}

sub _flush {
    my $self = shift;

    my $sock = $self->{sock} or return;
    return unless length $self->{wbuf};

    my $wrote = syswrite( $sock, $self->{wbuf} );

    if ( !defined $wrote ) {
        return if $! == EWOULDBLOCK || $! == EAGAIN || $! == EINTR;
        return $self->_dropLink("write: $!");
    }

    substr( $self->{wbuf}, 0, $wrote, '' );

    # Only babysit writability while there is a remainder to push.
    if ( length $self->{wbuf} ) {
        Slim::Networking::Select::addWrite( $sock, sub { $self->_flush } );
    }
    else {
        Slim::Networking::Select::removeWrite($sock);
    }

    return;
}

# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------
sub _readable {
    my $self = shift;

    my $sock = $self->{sock} or return;

    my $got = sysread( $sock, my $chunk, 65536 );

    if ( !defined $got ) {
        return if $! == EWOULDBLOCK || $! == EAGAIN || $! == EINTR;
        return $self->_dropLink("read: $!");
    }

    if ( $got == 0 ) {
        my $verb = $self->{inflight} ? $self->{inflight}->{verb} : undef;
        return $self->_dropLink(
            $verb ? "HQPlayer closed the link while <$verb> was outstanding"
                  : 'HQPlayer closed the link'
        );
    }

    $self->{rbuf} .= $chunk;

    # Drain every complete message the read produced.  Because <Status/> is a
    # subscribe, a single read routinely contains several.
    # DECODE HERE, not before: `rbuf` is octets off the wire, and framing a
    # message has to count the same units the socket delivered.  Each COMPLETE
    # message is turned back into characters on the way out, so callers - and
    # anything that ends up in a log line or a track title - see text rather
    # than mojibake.  The counterpart of the encode in _pump.
    while ( defined( my $raw = _extractMessage( \$self->{rbuf} ) ) ) {
        $self->_dispatch( Encode::decode( 'UTF-8', $raw ) );
    }

    return;
}

sub _dispatch {
    my ( $self, $raw ) = @_;

    my ($root) = $raw =~ /<([A-Za-z_][\w:.-]*)/;
    $root = '' unless defined $root;
    $root = '' if $root eq '?xml';

    # Skip a leading declaration when reading the root element name.
    if ( $raw =~ /<\?xml.*?\?>\s*<([A-Za-z_][\w:.-]*)/s ) {
        $root = $1;
    }

    # A complete message off the wire is the first real evidence that this
    # link works.  See _connectResolved for why the handshake is not.
    if ( !$self->{proven} ) {
        $self->{proven}  = 1;
        $self->{backoff} = BACKOFF_MIN;
        $self->{quiet}   = 0;      # the outage is over; the next one is news

        if ( $self->{onProven} ) {
            eval { $self->{onProven}->($self) };
            $log->error("$self->{name}: onProven handler died: $@") if $@;
        }
    }

    my $attrs = parseAttrs($raw);
    my $req   = $self->{inflight};
    my $isErr = ( $attrs->{result} || '' ) eq 'Error';

    # Every Status goes to the status handler, whether it was asked for or
    # pushed - that is what drives the player's state machine.
    if ( $root eq 'Status' && $self->{onStatus} && !$isErr ) {
        eval { $self->{onStatus}->( $attrs, $raw ) };
        $log->error("$self->{name}: onStatus handler died: $@") if $@;
    }

    return unless $req;

    # Match the reply to the outstanding request by root element name.
    # VERIFIED with strict one-in-flight serialisation against a live daemon:
    # EVERY command answers with its own tag - <Pause/> answers <Pause>, and
    # <Stop/> answers <Stop>.  (An earlier note here claimed those two answer
    # with a full <Status/>; that was an artifact of reading a subscribed push
    # stream without framing it properly, and matching on it would let a pushed
    # Status resolve a Pause.)  So the rule is simply: same tag, or not a reply.
    return unless $root eq $req->{verb};

    main::DEBUGLOG && $log->is_debug && $log->debug("$self->{name}: <- [$root] for <$req->{verb}>");

    my $now   = Time::HiRes::time();
    my $queue = defined $req->{sentAt} && defined $req->{queuedAt}
        ? $req->{sentAt} - $req->{queuedAt} : 0;
    my $wire  = defined $req->{sentAt} ? $now - $req->{sentAt} : 0;
    my $total = $queue + $wire;

    # PlaylistAdd is the only ordinary command which makes HQPlayer fetch and
    # probe media before replying. When a load feels intermittent, these two
    # figures distinguish waiting behind older control work from the media
    # probe itself without requiring DEBUG logging (which includes signed
    # service URLs). Fast replies remain debug-only noise.
    if ( $req->{verb} eq 'PlaylistAdd' && $total >= SLOW_COMMAND ) {
        $log->info( "$self->{name}: <PlaylistAdd> took "
            . sprintf( '%.2fs (queue %.2fs, HQPlayer %.2fs)', $total, $queue, $wire ) );
    }

    delete $self->{inflight};
    Slim::Utils::Timers::killTimers( $self, \&_replyTimeout );

    if ($isErr) {
        # `+`, NOT `*`. Every reply carries the XML declaration, so `*` matched
        # the EMPTY string between `?>` and `<Verb` and $msg came back "" for
        # every error on the wire - which silently disabled %BENIGN below and
        # printed the raw frame instead of the message. Measured live
        # 2026-09-26 on `<Volume>` against an empty playlist, the one case
        # %BENIGN exists for. `>` inside the text is fine: `[^<]` spans it, so
        # `trackn > last` survives whole.
        my ($msg) = $raw =~ />([^<]+)</;

        my $benign = $BENIGN{ $req->{verb} };
        my $lvl    = ( $benign && defined $msg && $msg =~ $benign ) ? 'debug' : 'warn';

        $log->$lvl("$self->{name}: <$req->{verb}> failed: " . ( $msg || $raw ));
        $req->{cb}->( undef, $raw ) if $req->{cb};
    }
    else {
        $req->{cb}->( $attrs, $raw ) if $req->{cb};
    }

    $self->_pump;

    return;
}

# Pull exactly ONE complete message off the front of the buffer, consuming it.
# Returns undef (leaving the buffer untouched) when no complete message is
# present yet.
sub _extractMessage {
    my $bufref = shift;

    $$bufref =~ s/^\s+//;
    return undef unless length $$bufref;

    my $off = 0;
    $off = $+[0] if $$bufref =~ /^<\?xml.*?\?>/s;

    my $rest = substr( $$bufref, $off );
    return undef unless $rest =~ /^\s*<([A-Za-z_][\w:.-]*)/;
    my $tag = $1;

    # Self-closing root: no '>' may appear before the '/>'.
    if ( $rest =~ m{^\s*<\Q$tag\E\b[^>]*?/>}s ) {
        my $end = $off + $+[0];
        return substr( $$bufref, 0, $end, '' );
    }

    my $close = index( $$bufref, "</$tag>", $off );
    return undef if $close < 0;

    my $end = $close + length("</$tag>");

    return substr( $$bufref, 0, $end, '' );
}

# ---------------------------------------------------------------------------
# Teardown
# ---------------------------------------------------------------------------
sub _dropLink {
    my ( $self, $why ) = @_;

    my $wasUp     = $self->{connected};
    my $wasProven = $self->{proven};

    Slim::Utils::Timers::killTimers( $self, \&_connectTimeout );
    Slim::Utils::Timers::killTimers( $self, \&_replyTimeout );

    if ( my $sock = delete $self->{sock} ) {
        Slim::Networking::Select::removeRead($sock);
        Slim::Networking::Select::removeWrite($sock);
        Slim::Networking::Select::removeError($sock);
        CORE::close($sock);
    }

    $self->{connected}  = 0;
    $self->{connecting} = 0;
    $self->{proven}     = 0;
    $self->{wbuf}       = '';
    $self->{rbuf}       = '';

    # A link that had been ANSWERING going down is always worth a line. A
    # failed attempt during an outage is not - see _outage.
    if ( $wasProven && !$self->{oneShot} ) {
        $log->warn("$self->{name}: control link down - $why");
        $self->{quiet} = 1;
    }
    elsif ($wasUp) {
        $self->_outage("control link down - $why");
    }
    elsif ( $log->is_debug ) {
        $log->debug("$self->{name}: control link down - $why");
    }

    # $wasProven: whether this link had carried a reply, i.e. whether LMS was
    # told it was connected (Player::connected is `proven`). Passed because
    # `proven` is already cleared above, so the listener cannot ask.
    #
    # THE LISTENER HEARS FIRST, BEFORE ANY STRANDED COMMAND IS FAILED. A synced
    # player leaves its group here (Plugin::_onLinkState -> playerInactive ->
    # Player::stop), and stop() retires the load it had in flight by bumping the
    # generation. Failed the other way round, that load's callback would report
    # a failed load to LMS first, and LMS fails a track for the WHOLE group when
    # one member cannot open it - every other room skipping for one lost link.
    # The socket is already gone, so anything the listener sends is failed on
    # the next turn (see send) rather than queued behind the commands below.
    $self->{onState}->( $self, 0, $wasProven ) if $wasUp && $self->{onState};

    # Fail the outstanding command and everything queued behind it, so callers
    # are never left waiting on a callback that can no longer arrive.
    my $req = delete $self->{inflight};
    $req->{cb}->( undef, undef ) if $req && $req->{cb};

    while ( my $q = shift @{ $self->{queue} } ) {
        $q->{cb}->( undef, undef ) if $q->{cb};
    }

    $self->_scheduleReconnect unless $self->{closing};

    return;
}

# ONE warning per outage, not one per retry. While HQPlayer is off, restarting,
# or accepting and then resetting the socket, every retry fails the same way,
# and the link retries every BACKOFF_MAX (10s) at most: at WARN that was a line
# every ~11s for as long as it lasted - 401 of the bridge's 414 lines in a
# 6.5-hour log (2026-09-25, one instance that accepts and resets).
#
# A one-shot identify logs nothing above debug: it is a new object each round,
# so its own `quiet` could never hold, and its caller reports once per outage.
# The first failure is reported; the rest go to debug until HQPlayer answers
# again (_dispatch clears `quiet`), and a working link that drops is always
# reported (_dropLink).
sub _outage {
    my ( $self, $msg ) = @_;

    if ( $self->{quiet} || $self->{oneShot} ) {
        main::DEBUGLOG && $log->is_debug && $log->debug("$self->{name}: $msg");
        return;
    }

    $self->{quiet} = 1;
    $log->warn("$self->{name}: $msg - further attempts are logged at debug until it answers");

    return;
}

sub _scheduleReconnect {
    my $self = shift;

    return if $self->{closing} || $self->{oneShot};

    my $delay = $self->{backoff};
    $self->{backoff} = $self->{backoff} * 2 > BACKOFF_MAX ? BACKOFF_MAX : $self->{backoff} * 2;

    main::DEBUGLOG && $log->is_debug && $log->debug("$self->{name}: reconnecting in ${delay}s");

    Slim::Utils::Timers::killTimers( $self, \&_reconnect );
    Slim::Utils::Timers::setTimer( $self, Time::HiRes::time() + $delay, \&_reconnect );

    return;
}

sub _reconnect {
    my $self = shift;
    $self->connect;
}

sub close {
    my $self = shift;

    $self->{closing} = 1;
    Slim::Utils::Timers::killTimers( $self, \&_reconnect );
    $self->_dropLink('shutting down');

    return;
}

# ---------------------------------------------------------------------------
# Who is at this address? One connection, one <GetInfo/>, closed again.
#
# For an address typed into the settings, which has no discovery reply to
# name it. <GetInfo/>'s `name` IS the name discovery reports - measured on
# Embedded across a rename (HQPlayerEmbedded, then ManCave) and on Desktop
# 6.2.3 (`name="Mac"` both ways), 2026-09-20 and 2026-09-27 - so an instance
# reached this way gets the SAME player id discovery would have given it, and
# no player is ever re-keyed.
#
# $cb->($attrs) with GetInfo's attributes, or $cb->(undef) when nothing
# answered: refused, timed out, closed, or an error reply. A oneShot link
# never reconnects, so a dead host costs exactly this one attempt.
# ---------------------------------------------------------------------------
sub identify {
    my ( $class, $ip, $cb ) = @_;

    my $self = $class->new( ip => $ip, name => "HQPlayer at $ip", oneShot => 1 );

    $self->connect;

    $self->send( '<GetInfo/>', sub {
        my ($attrs) = @_;

        # Closed on the NEXT turn: this runs inside _dispatch or _dropLink,
        # and closing from in there would tear the link down under them.
        Slim::Utils::Timers::setTimer( $self, Time::HiRes::time(), \&_closeOneShot );

        $cb->($attrs) if $cb;
    } );

    return $self;
}

sub _closeOneShot { $_[0]->close }

# ---------------------------------------------------------------------------
# Tiny XML helpers.  These payloads are small, flat and machine-generated, so
# a full parser would be more dependency than the job needs.
# ---------------------------------------------------------------------------
sub parseAttrs {
    my $frag = shift or return {};

    # Attributes of the first (root) element only.
    my ($head) = $frag =~ /<[A-Za-z_][\w:.-]*\b([^>]*)>/s;
    return {} unless defined $head;

    my %a;
    while ( $head =~ /([\w:.-]+)\s*=\s*"([^"]*)"/g ) {
        $a{$1} = unescape($2);
    }

    return \%a;
}

# Return a list of attribute hashes for every <$tag .../> inside $frag.
sub parseChildren {
    my ( $frag, $tag ) = @_;
    return () unless $frag;

    my @out;
    while ( $frag =~ m{<\Q$tag\E\b([^>]*?)/?>}gs ) {
        my $head = $1;
        my %a;
        while ( $head =~ /([\w:.-]+)\s*=\s*"([^"]*)"/g ) {
            $a{$1} = unescape($2);
        }
        push @out, \%a;
    }

    return @out;
}

# HQPlayer's exact attribute spelling is not fully pinned down yet, so every
# read goes through here and accepts any of the plausible names.
sub pick {
    my ( $attrs, @names ) = @_;
    return undef unless ref $attrs eq 'HASH';

    for my $n (@names) {
        return $attrs->{$n} if defined $attrs->{$n} && $attrs->{$n} ne '';
        # case-insensitive fallback
        for my $k ( keys %$attrs ) {
            return $attrs->{$k} if lc($k) eq lc($n) && defined $attrs->{$k} && $attrs->{$k} ne '';
        }
    }

    return undef;
}

sub escape {
    my $s = shift;
    return '' unless defined $s;
    $s =~ s/&/&amp;/g;
    $s =~ s/</&lt;/g;
    $s =~ s/>/&gt;/g;
    $s =~ s/"/&quot;/g;
    $s =~ s/'/&apos;/g;
    return $s;
}

sub unescape {
    my $s = shift;
    return '' unless defined $s;
    $s =~ s/&lt;/</g;
    $s =~ s/&gt;/>/g;
    $s =~ s/&quot;/"/g;
    $s =~ s/&apos;/'/g;
    $s =~ s/&amp;/&/g;
    return $s;
}

1;
